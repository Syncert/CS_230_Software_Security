package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication; //original
import org.springframework.boot.autoconfigure.SpringBootApplication; //original
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController {

    // Convert byte array to hex string
    private static String bytesToHex(byte[] hash) {
    	//initialize stringbuilder 2* the length of bytes because each 
    	//byte is represented by two hexademical digits
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b); // Convert byte to hex string
            if(hex.length() == 1) hexString.append('0'); // Append leading zero if hex string has only one digit
            hexString.append(hex); // Append hex string to the final StringBuilder
        }
        return hexString.toString();
    }
    
    @RequestMapping("/hash")
    public String myHash() {
        String data = "Nicholas Kreuziger - This is a test";  // Unique Data String
        
        // Generate checksum using SHA-2
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256"); // Using SHA-256 algorithm
            
            // Compute the hash value as byte array
            byte[] hashBytes = digest.digest(data.getBytes());
            
            // Convert byte array to hex string
            String hashString = bytesToHex(hashBytes);
            
            return "<p>Data: " + data + "</p><p>Hash: " + hashString + "</p>";
            
        } catch (NoSuchAlgorithmException e) {
            return "<p>Error: Algorithm not found</p>";
        }
    }
}